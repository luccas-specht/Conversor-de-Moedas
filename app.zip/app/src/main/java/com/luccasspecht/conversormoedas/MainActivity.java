package com.luccasspecht.conversormoedas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ViewHolder mViewholder = new ViewHolder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mViewholder.editvalue = findViewById(R.id.edit_valor);
        this.mViewholder.textdolar = findViewById(R.id.text_dolar);
        this.mViewholder.buttonconverter = findViewById(R.id.button_converter);
        this.mViewholder.spin = findViewById(R.id.aspinner);
        this.mViewholder.buttonconverter.setOnClickListener(this);



        this.Beging();



    }

    private static class ViewHolder {
        EditText editvalue;
        TextView textdolar;
        Button buttonconverter;
        Spinner spin;


    }







    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button_converter) {
            String value = this.mViewholder.editvalue.getText().toString();
            if ("".equals(value)) {
                Toast.makeText(this, this.getString(R.string.informe_valor), Toast.LENGTH_LONG).show();
                this.Beging();

            } else {

                Double real = Double.valueOf(value);
                String item = this.mViewholder.spin.getSelectedItem().toString();

                if (item.equals("Dollar")) {
                    this.mViewholder.textdolar.setText(String.format("%.2f", vDolar(real)));
                }

                if (item.equals("Euro")) {
                    this.mViewholder.textdolar.setText(String.format("%.2f", vEuro(real)));
                }
                if (item.equals("Iene")) {
                    this.mViewholder.textdolar.setText(String.format("%.2f", vIene(real)));
                }

                if (item.equals("Rublo")) {
                    this.mViewholder.textdolar.setText(String.format("%.2f", vRublo(real)));
                }

                if (item.equals("Peso")) {
                    this.mViewholder.textdolar.setText(String.format("%.2f", vPeso(real)));
                }

                if (item.equals("Bitcoin")) {
                    this.mViewholder.textdolar.setText(String.format("%.2f", vBitcoin(real)));

                }
            }
        }
    }













    private void Beging() {
        this.mViewholder.textdolar.setText("0.00");

    }


    private void ClearValues() {
        this.mViewholder.textdolar.setText("");

    }


    public static double vPeso(double r) {

        return r / 0.07;
    }


    public static double vDolar(double r) {

        return r / 4.34;
    }

    public static double vEuro(double r) {

        return r / 4.76;
    }

    public static double vIene(double r) {

        return r / 0.039;
    }

    public static double vRublo(double r) {

        return r / 0.068;
    }

    public static double vBitcoin(double r) {

        return r / 0.000023;
    }


}
